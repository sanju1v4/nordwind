# Nordwind - mini enterprise AI platform

A working version of the Nordwind case study, built the right way, step by step.

## Steps so far
1. Postgres + pgvector in Docker Compose
2. API skeleton (Express + tRPC) and React frontend (Vite), with liveness/readiness checks

## Run it (Windows PowerShell, from E:\Nordwind)

```powershell
copy .env.example .env          # then change the password in .env (both places)
docker compose up -d            # start Postgres
docker exec -it nordwind-db psql -U nordwind -d nordwind -c "CREATE EXTENSION IF NOT EXISTS vector;"
npm install                     # installs api + web dependencies
npm run dev:api                 # terminal 1 -> http://localhost:3000
npm run dev:web                 # terminal 2 -> http://localhost:5173
```

## Check it works
- http://localhost:3000/livez  -> `ok` (process alive; never depends on the DB or an AI provider)
- http://localhost:3000/readyz -> `ready` (DB reachable), or 503 if the DB is down
- http://localhost:5173        -> shows API message, Postgres version and pgvector version
