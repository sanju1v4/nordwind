import { useEffect, useState } from "react";
import { api } from "./trpc";

type Status = { hello?: string; postgres?: string; pgvector?: string | null; error?: string };

export function App() {
  const [status, setStatus] = useState<Status>({});

  useEffect(() => {
    Promise.all([api.hello.query({ name: "Sai" }), api.dbStatus.query()])
      .then(([hello, db]) => setStatus({ hello: hello.message, postgres: db.postgres, pgvector: db.pgvector }))
      .catch((err: unknown) => setStatus({ error: err instanceof Error ? err.message : String(err) }));
  }, []);

  return (
    <main style={{ fontFamily: "system-ui, sans-serif", maxWidth: 560, margin: "64px auto", lineHeight: 1.6 }}>
      <h1>Nordwind</h1>
      {status.error && <p style={{ color: "crimson" }}>API error: {status.error}</p>}
      {!status.error && !status.hello && <p>Connecting to API...</p>}
      {status.hello && (
        <ul>
          <li>API: {status.hello}</li>
          <li>Database: {status.postgres}</li>
          <li>pgvector: {status.pgvector ?? "NOT installed - run the CREATE EXTENSION command"}</li>
        </ul>
      )}
    </main>
  );
}
