import { createTRPCClient, httpBatchLink } from "@trpc/client";
// "import type" = only the TypeScript types come over; no server code reaches the browser.
import type { AppRouter } from "../../api/src/router";

export const api = createTRPCClient<AppRouter>({
  links: [
    httpBatchLink({
      url: "http://localhost:3000/trpc",
      // Send cookies with each request; needed for login in step 3.
      fetch: (url, options) => fetch(url, { ...options, credentials: "include" }),
    }),
  ],
});
