import express from "express";
import cors from "cors";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "./router.js";
import { db } from "./db.js";

const app = express();
const port = Number(process.env.API_PORT ?? 3000);

// Only our own frontend may call the API from a browser.
app.use(cors({ origin: process.env.WEB_ORIGIN ?? "http://localhost:5173", credentials: true }));

// Liveness: "is this process alive?" Never depends on the database or an AI provider (case study R1).
app.get("/livez", (_req, res) => {
  res.send("ok");
});

// Readiness: "can this process serve traffic right now?" Checks only what we own: the database.
app.get("/readyz", async (_req, res) => {
  try {
    await db.query("SELECT 1");
    res.send("ready");
  } catch {
    res.status(503).send("database unavailable");
  }
});

app.use(
  "/trpc",
  express.json({ limit: "1mb" }), // small on purpose: files will go straight to S3 later (case study S9)
  createExpressMiddleware({ router: appRouter, createContext: () => ({}) }),
);

const server = app.listen(port, () => {
  console.log(`API listening on http://localhost:${port}`);
});

// Graceful shutdown: finish in-flight requests before exiting (case study O5).
process.on("SIGTERM", () => {
  server.close(() => {
    void db.end().then(() => process.exit(0));
  });
});
