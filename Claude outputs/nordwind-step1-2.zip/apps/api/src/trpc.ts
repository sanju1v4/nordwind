import { initTRPC } from "@trpc/server";

// The context is what every procedure receives. Later (step 3) it will hold
// the logged-in user, read from a verified token - never from the request body.
export type Context = Record<string, never>;

const t = initTRPC.context<Context>().create();

export const router = t.router;
export const publicProcedure = t.procedure;
