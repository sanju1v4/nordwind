import { z } from "zod";
import { router, publicProcedure } from "./trpc.js";
import { db } from "./db.js";

export const appRouter = router({
  // A first endpoint to prove browser -> API works.
  hello: publicProcedure
    .input(z.object({ name: z.string().min(1).max(50) }))
    .query(({ input }) => ({ message: `Hello ${input.name}, Nordwind API is running` })),

  // Proves API -> Postgres works and that the pgvector extension is installed.
  dbStatus: publicProcedure.query(async () => {
    const { rows } = await db.query<{ version: string; vector: string | null }>(
      "SELECT version() AS version, (SELECT extversion FROM pg_extension WHERE extname = 'vector') AS vector",
    );
    return { postgres: rows[0].version.split(" ").slice(0, 2).join(" "), pgvector: rows[0].vector };
  }),
});

// Only the TYPE is exported to the frontend, so the browser gets autocomplete and type checks
// for every API call without any server code being shipped to it.
export type AppRouter = typeof appRouter;
